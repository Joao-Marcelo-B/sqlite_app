package com.example.sqlite_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
